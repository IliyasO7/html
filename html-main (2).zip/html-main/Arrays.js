const fruits = ["Apple","oranges","pineApples"];
console.log(fruits.length); //length of arr
console.log(fruits[1]); //accesing elements
fruits.unshift("Strawberry"); //add at start

fruits.push("mangoes");// adds at end
console.log(fruits);
fruits.pop(); //pops end element
console.log(fruits);
console.log(fruits.indexOf("oranges"));